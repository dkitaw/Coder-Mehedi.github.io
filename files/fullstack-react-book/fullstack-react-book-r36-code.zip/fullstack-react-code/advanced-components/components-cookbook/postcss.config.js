module.exports = {
  plugins: {
    'postcss-nested': {},
    precss: {}
  }
};
