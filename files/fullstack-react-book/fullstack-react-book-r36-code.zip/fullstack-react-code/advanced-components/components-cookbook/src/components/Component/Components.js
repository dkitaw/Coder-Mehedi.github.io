import React from 'react';

// ES6 class-style
class ComponentApp extends React.Component {
  render() {} // required
}

export default ComponentApp;
