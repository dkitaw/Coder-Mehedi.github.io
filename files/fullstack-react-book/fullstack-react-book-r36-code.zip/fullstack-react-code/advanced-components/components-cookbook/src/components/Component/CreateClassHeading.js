import React from 'react';
import createReactClass from 'create-react-class';

const CreateClassHeading = createReactClass({
  render: function() {
    return <h1>Hello</h1>;
  }
});

export default CreateClassHeading;
