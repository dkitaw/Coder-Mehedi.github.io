import React, { PropTypes } from 'react';

class Switch extends React.Component {
  state = {};

  render() {
    return <div><em>Template will be here</em></div>;
  }
}

module.exports = Switch;
