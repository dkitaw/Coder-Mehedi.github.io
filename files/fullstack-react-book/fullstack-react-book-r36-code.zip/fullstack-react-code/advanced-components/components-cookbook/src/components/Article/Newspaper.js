import React from 'react'

const Newspaper = props => {
  return (
    <Container>
      <Article headline="An interesting Article">
        Content Here
      </Article>
    </Container>
  )
}

export default Newspaper
